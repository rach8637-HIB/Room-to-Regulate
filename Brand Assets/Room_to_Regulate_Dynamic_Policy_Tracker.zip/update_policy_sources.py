#!/usr/bin/env python3
"""Update source-updates.json from feeds associated with the Verified Resources list.

Source headlines are leads for editorial review, never confirmed policy changes.
Run on a schedule in a trusted server/repository; publish JSON only after this succeeds.
"""
from __future__ import annotations
import json, os, re, tempfile, urllib.request, urllib.parse, xml.etree.ElementTree as ET
from datetime import datetime, timezone, timedelta
from email.utils import parsedate_to_datetime
from html import unescape
from pathlib import Path

HERE=Path(__file__).resolve().parent
DEST=HERE/'source-updates.json'
FEEDS=[
 ('KFF · Medicaid','Medicaid and Medicare','https://www.kff.org/topic/medicaid/feed/',('kff.org',)),
 ('KFF · Medicare','Medicaid and Medicare','https://www.kff.org/topic/medicare/feed/',('kff.org',)),
 ('KFF · Affordable Care Act','Insurance and vaccines','https://www.kff.org/topic/affordable-care-act/feed/',('kff.org',)),
 ('KFF · State health policy','State policy','https://www.kff.org/topic/state-health-policy-data/feed/',('kff.org',)),
 ('USDA FNA · Newsroom','Education and food assistance','https://www.fna.usda.gov/rss-feeds/newsroom',('fna.usda.gov','fns.usda.gov')),
 ('USDA FNA · Federal Register','Education and food assistance','https://www.fna.usda.gov/rss-feeds/federal-register',('fna.usda.gov','fns.usda.gov','federalregister.gov')),
]
MAX_BYTES=2_000_000

def text(node,tag):
 x=node.find(tag)
 return ''.join(x.itertext()).strip() if x is not None else ''

def compact(s):return re.sub(r'\s+',' ',unescape(re.sub('<[^>]+>',' ',s or ''))).strip()

def permitted(url,hosts):
 u=urllib.parse.urlsplit(url)
 return u.scheme=='https' and any(u.hostname==host or (u.hostname or '').endswith('.'+host) for host in hosts)

def fetch_feed(feed):
 name,topic,url,hosts=feed
 req=urllib.request.Request(url,headers={'User-Agent':'RoomToRegulatePolicyMonitor/1.0 (source headlines; editorial review)','Accept':'application/rss+xml, application/xml, text/xml'})
 with urllib.request.urlopen(req,timeout=15) as resp:
  if not permitted(resp.geturl(),hosts):raise ValueError('unexpected redirect domain')
  raw=resp.read(MAX_BYTES+1)
 if len(raw)>MAX_BYTES:raise ValueError('feed too large')
 root=ET.fromstring(raw)
 if root.tag!='rss':raise ValueError('expected RSS feed')
 result=[]
 for item in root.findall('./channel/item')[:18]:
  title=compact(text(item,'title'))[:240]
  link=text(item,'link').strip()
  if not title or not permitted(link,hosts):continue
  date=text(item,'pubDate') or text(item,'{http://purl.org/dc/elements/1.1/}date')
  try:published=parsedate_to_datetime(date).astimezone(timezone.utc).date().isoformat()
  except (ValueError,TypeError):published=None
  result.append({'title':title,'url':link,'source':name,'topic':topic,'published':published})
 return result

def main():
 previous={}
 if DEST.exists():
  try:previous=json.loads(DEST.read_text())
  except (ValueError,OSError):pass
 old=previous.get('items',[])
 sources=[];items=[];success=0
 for feed in FEEDS:
  name=feed[0]
  try:
   entries=fetch_feed(feed)
   if not entries:raise ValueError('no valid items')
   items.extend(entries);sources.append({'name':name,'status':'ok','count':len(entries)});success+=1
  except Exception as e:
   retained=[x for x in old if x.get('source')==name]
   items.extend(retained);sources.append({'name':name,'status':'stale','count':len(retained),'error':type(e).__name__})
 if success==0:raise RuntimeError('no feeds refreshed; kept previous JSON unchanged')
 unique={x['url']:x for x in items}
 items=sorted(unique.values(),key=lambda x:x.get('published') or '',reverse=True)[:70]
 payload={'schemaVersion':1,'fetchedAt':datetime.now(timezone.utc).isoformat(timespec='seconds'),
  'notice':'Automatically collected headlines from selected Verified Resources. A source update is not necessarily a policy change. Read the original and check effective dates.',
  'sources':sources,'items':items}
 fd,tmp=tempfile.mkstemp(prefix='.source-updates-',suffix='.json',dir=HERE)
 try:
  with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(payload,f,ensure_ascii=False,indent=2);f.write('\n')
  os.replace(tmp,DEST)
 finally:
  if os.path.exists(tmp):os.unlink(tmp)
 print(f'Refreshed {success}/{len(FEEDS)} sources; {len(items)} unique headlines in {DEST.name}')
 for src in sources:print(src['status'],src['name'],src['count'])

if __name__=='__main__':main()
